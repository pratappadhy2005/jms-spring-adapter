package com.au.pratap;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

/**
 * @author Pratap
 */
@SpringBootApplication
public class StripFileProducerClientApplication {

    public static void main(String[] args) {
        SpringApplication.run(StripFileProducerClientApplication.class, args);
    }

}
